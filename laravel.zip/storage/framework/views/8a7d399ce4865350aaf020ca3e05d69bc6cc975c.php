
<?php $__env->startSection('admincontent'); ?>
    <div class="page-wrapper">
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Pengaturan Web</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Pengaturan
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('pengaturan.create')); ?>">
                                <button type="button" class="btn btn-primary">Tambah Data</button>
                            </a>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Tabel Pengaturan</h5>
                            <div class="table-responsive">
                                <table id="zero_config" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th><b>Logo</b></th>
                                            <th><b>Nama Website</b></th>
                                            <th><b>Deskripsi</b></th>
                                            <th><b>Email</b></th>
                                            <th><b>No Telepon</b></th>
                                            <th><b>Alamat</b></th>
                                            <th><b>Link Map</b></th>
                                            <th><b>Link Facebook</b></th>
                                            <th><b>Link Twitter</b></th>
                                            <th><b>Link Instagram</b></th>
                                            <th><b>Aksi</b></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><img src="<?php echo e(asset('logo/' . $ambil->logo)); ?>" width='75' height='75'>
                                                </td>
                                                <td><?php echo e($ambil->nama_web); ?></td>
                                                <td><?php echo e($ambil->deskripsi); ?></td>
                                                <td><?php echo e($ambil->email); ?></td>
                                                <td><?php echo e($ambil->no_telp); ?></td>
                                                <td><?php echo e($ambil->alamat); ?></td>
                                                <td><?php echo e($ambil->link_map); ?></td>
                                                <td><?php echo e($ambil->link_facebook); ?></td>
                                                <td><?php echo e($ambil->link_twitter); ?></td>
                                                <td><?php echo e($ambil->link_ig); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('pengaturan.edit', ['id' => $ambil->id])); ?>">
                                                        <button type="button" class="btn btn-sm btn-info">Edit</button>
                                                    </a>
                                                    <a href="<?php echo e(route('pengaturan.destroy', ['id' => $ambil->id])); ?>"
                                                        onclick="return confirm('Hapus data?');">
                                                        <button type="button" class="btn btn-sm btn-danger">Hapus</button>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3">
                                                    <center>Data kosong</center>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        </tfoot>
                                </table>
                                <div class="card-footer text-right">
                                    <nav class="d-inline-block">
                                        <?php echo $data->appends(request()->except('page'))->render(); ?>

                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\05.TUGAS SEKOLAH-Kuliah\+KULIAH\PKL\Project PKL\umkm\laravel\resources\views/pengaturan/index.blade.php ENDPATH**/ ?>