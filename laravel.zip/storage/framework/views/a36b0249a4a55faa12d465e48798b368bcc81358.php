
<?php $__env->startSection('admincontent'); ?>
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Navigasi</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Navigasi
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('navigasi.create')); ?>">
                                <button type="button" class="btn btn-primary">Tambah Data</button>
                            </a>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Tabel Navigasi</h5>
                            <div class="table-responsive">
                                <table id="zero_config" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th><b>Name Navigasi</b></th>
                                            <th><b>Link</b></th>
                                            <th><b>Judul Konten</b></th>
                                            <th><b>Isi Konten</b></th>
                                            <th><b>Gambar</b></th>
                                            <th><b>Kategori</b></th>
                                            <th><b>Aktif</b></th>
                                            <th><b>Aksi</b></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($nav->nama_navigasi); ?></td>
                                                <td><?php echo e($nav->link); ?></td>
                                                <td><?php echo e($nav->judul_konten); ?></td>
                                                <td><?php echo e($nav->isi_konten); ?></td>
                                                <td><img src="<?php echo e(asset('gambar_artikel/' . $nav->gambar)); ?>" width='75'
                                                        height='75'></td>
                                                <td><?php echo e($nav->relasiKategori->nama_kategori); ?></td>
                                                <td><?php echo e($nav->aktif); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('navigasi.edit', ['id' => $nav->id])); ?>">
                                                        <button type="button" class="btn btn-sm btn-info">Edit</button>
                                                    </a>
                                                    <a href="<?php echo e(route('navigasi.destroy', ['id' => $nav->id])); ?>"
                                                        onclick="return confirm('Hapus data?');">
                                                        <button type="button" class="btn btn-sm btn-danger">Hapus</button>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3">
                                                    <center>Data kosong</center>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        </tfoot>
                                </table>
                                <div class="card-footer text-right">
                                    <nav class="d-inline-block">
                                        <?php echo $data->appends(request()->except('page'))->render(); ?>

                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End PAge Content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- .right-sidebar -->
            <!-- ============================================================== -->
            <!-- End Right sidebar -->
            <!-- ============================================================== -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\05.TUGAS SEKOLAH-Kuliah\+KULIAH\PKL\Project PKL\umkm\laravel\resources\views/navigasi/index.blade.php ENDPATH**/ ?>