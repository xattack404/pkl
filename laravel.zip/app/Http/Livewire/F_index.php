<?php

namespace App\Http\Livewire;

use Livewire\Component;

class F_index extends Component
{
    public function render()
    {
        return view('livewire.index');
    }
}
